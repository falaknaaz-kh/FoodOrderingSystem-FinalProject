package com.foodies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendUpdatedApplicationTests {

	@Test
	void contextLoads() {
	}

}
