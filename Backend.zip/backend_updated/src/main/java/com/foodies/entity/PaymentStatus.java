package com.foodies.entity;

public enum PaymentStatus {
	PENDING,COMPLETED,REFUNDED
}
