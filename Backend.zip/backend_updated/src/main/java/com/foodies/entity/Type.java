package com.foodies.entity;

public enum Type {
	COD,CARD,UPI,NETBANKING
}
